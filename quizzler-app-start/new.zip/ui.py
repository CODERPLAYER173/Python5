from tkinter import *
from PIL import Image, ImageTk
import os

THEME_COLOR = "#375362"
CARD_COLOR = "#FFFFFF"
FONT_NAME = "Arial"

class QuizUI:

    def __init__(self, quiz_brain):
        self.quiz = quiz_brain

        self.window = Tk()
        self.window.title("Quizzler")
        self.window.config(padx=20, pady=20, bg=THEME_COLOR)
        self.window.minsize(350, 500)

        # Score label
        self.score_label = Label(
            text="Score: 0",
            fg="white",
            bg=THEME_COLOR,
            font=(FONT_NAME, 16)
        )
        self.score_label.grid(row=0, column=1, sticky="e", pady=(0, 10))

        # Question card (Canvas)
        self.canvas = Canvas(
            width=300,
            height=250,
            bg=CARD_COLOR,
            highlightthickness=0
        )
        self.question_text = self.canvas.create_text(
            150, 125,
            width=280,
            text="",
            fill=THEME_COLOR,
            font=(FONT_NAME, 16, "italic")
        )
        self.canvas.grid(row=1, column=0, columnspan=2, pady=40)

        # Load button images
        # Try to find images relative to this file, then fall back to cwd
        base_dir = os.path.dirname(os.path.abspath(__file__))
        true_path = os.path.join(base_dir, "true.png")
        false_path = os.path.join(base_dir, "false.png")

        true_img_raw = Image.open(true_path).resize((100, 100), Image.LANCZOS)
        false_img_raw = Image.open(false_path).resize((100, 100), Image.LANCZOS)
        self.true_img = ImageTk.PhotoImage(true_img_raw)
        self.false_img = ImageTk.PhotoImage(false_img_raw)

        # True button
        self.true_button = Button(
            image=self.true_img,
            highlightthickness=0,
            bd=0,
            bg=THEME_COLOR,
            activebackground=THEME_COLOR,
            cursor="hand2",
            command=self.true_pressed
        )
        self.true_button.grid(row=2, column=0, pady=20)

        # False button
        self.false_button = Button(
            image=self.false_img,
            highlightthickness=0,
            bd=0,
            bg=THEME_COLOR,
            activebackground=THEME_COLOR,
            cursor="hand2",
            command=self.false_pressed
        )
        self.false_button.grid(row=2, column=1, pady=20)

        self.get_next_question()
        self.window.mainloop()

    def get_next_question(self):
        self.canvas.config(bg=CARD_COLOR)
        if self.quiz.still_has_questions():
            q = self.quiz.question_list[self.quiz.question_number]
            self.quiz.current_question = q
            self.quiz.question_number += 1
            self.score_label.config(text=f"Score: {self.quiz.score}")
            # Decode HTML entities that may come from the API
            import html
            q_text = html.unescape(q.text)
            self.canvas.itemconfig(self.question_text, text=q_text)
        else:
            self.canvas.itemconfig(
                self.question_text,
                text=f"You've completed the quiz!\nFinal score: {self.quiz.score}/{self.quiz.question_number}"
            )
            self.true_button.config(state=DISABLED)
            self.false_button.config(state=DISABLED)

    def true_pressed(self):
        self.give_feedback(self.quiz.check_answer("True"))

    def false_pressed(self):
        self.give_feedback(self.quiz.check_answer("False"))

    def give_feedback(self, is_right):
        if is_right:
            self.canvas.config(bg="#00FF00")
        else:
            self.canvas.config(bg="#FF0000")
        self.window.after(1000, self.get_next_question)
